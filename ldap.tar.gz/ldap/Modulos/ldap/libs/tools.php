<?php


function getpassword(){
    
    define("AMP_CONF", "/etc/sysconfig/issabel-ldap");
    $file = file_get_contents(AMP_CONF);

        $fileDeseado = str_replace('OPTIONS="', '', $file); //se elimina OPTIONS="
        $fileDeseado= rtrim(trim($fileDeseado), '"');
    
        $indiceLdapPass = strpos($fileDeseado, '-ldappass');
        $password = substr($fileDeseado, $indiceLdapPass + strlen('-ldappass'));// Extraer el valor que sigue a -ldappass
        $password = trim($password);// Eliminar espacios en blanco alrededor del valor
    
    
        $password = explode(" ",$password);
      return $password[0];
  
};

function getstate(){
$status = statedeamon();

if ($status=="active") $S="<span style=\"color:green;font-weight:bold\">Activo</span>";
else $S= "<span style=\"color:red;font-weight:bold\">Desactivo</span>";
return $S;
}

function statedeamon(){
return trim(shell_exec('systemctl status issabel-ldap.service | grep Active: | awk \'{print $2}\''));  
}




?>