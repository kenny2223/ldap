<?php



$pas=getpassword();
$server=$_SERVER['SERVER_ADDR'];

?>


<div class="alert alert-success collapse" style="position: absolute;z-index: 100;" role="alert"></div>


<div class="container">

<div class="col-sm-4 col-lg-4">
  <div class="panel panel-default" >
    <div class="panel-heading" style='padding:0.3em' ><b>Servidor Ldap</b>  &nbsp;&nbsp;&nbsp;&nbsp; <b>Puerto:</b> 10389</div>
    <div class="panel-body">
    <?php 
    $state=statedeamon();
    $e = ($state == "active") ? 'disabled' : '';
      echo "<label style=\"display:block;\" >Estado: ".getstate()."</label>";
     
      echo "<button type=\"button\" class=\"btn btn-success\" id=\"ldap\" $e >Activar</button>";
      ?>
    </div>
  </div>
  </div>


  <div class="col-sm-3 col-lg-3">
    
  </div>




  
  </div>
  <div class="row">
  <div class="col-sm-12 col-lg-12">
<div class="panel panel-default">
  <div class="panel-body">

  <div class="row">
  <h5 class="col-sm-3 col-lg-3"><b>Base:</b> dc=asterisk</h5>
  <h5 class="col-sm-4 col-lg-4" ><b>Username:</b> cn=admin,dc=pbx,dc=com</h5>
  <h5 class="col-sm-3 col-lg-3 col-xs-2" ><b>Password:</b>&nbsp;<input type="text"  id="pass" class="form-control input-sm" placeholder="Password" value="<?php echo $pas ?>" style="width:50%;display:inline"></h5>
  </div>
<br>
  <div class="row">
  <h5 class="col-sm-4 col-lg-4"><b>Filtro Nombre:</b> (|(cn=%)(sn=%))</h5>
  <h5 class="col-sm-6 col-lg-6" ><b>Filtro Numero:</b> (|(telephoneNumber=%)(homePhone=%))</h5>
  </div>
<br>
<div class="row">
  <h5 class="col-sm-3 col-lg-3"><b>Atributo Nombre:</b> cn sn</h5>
  <h5 class="col-sm-5 col-lg-5" ><b>Atributo Numero:</b> telephoneNumber homePhone</h5>
  <h5 class="col-sm-2 col-lg-2" ><b>Display:</b> %cn</h5>
  </div>
  </div>
</div>
</div>




</div>
 


<button type="button" id="btnsave" class="btn btn-success" onclick="save()" disabled>Guardar</button>





