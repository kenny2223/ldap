
$(document).ready(function(){

  var btnsave = $('#btnsave');
  var pass = $('#pass').val().trim();

  $("#pass").on('keyup', function() {
    if ($(this).val().trim() !== pass) {
      btnsave.prop('disabled', false);
    }
    pass = $(this).val().trim();

  });

  $('#ldap').on('click', function() { 

     $.ajax
      ({
          type: 'POST',
          url:  'modules/ldap/ajax_peticion.php',
          data: {
           start : true
          },
          success: function(data)
          {
           location.reload();
          }
      });
  
  
    });

});

function save(){
  $.ajax
  ({
      type: 'POST',
      url:  'modules/ldap/ajax_peticion.php',
      data: {
       save : true,
       password:$('#pass').val().trim()
      },
      success: function(data)
      {

      $('#btnsave').prop('disabled', true);
       $('.alert').html("Guardado");
       $('.alert').css({"top":$(window).scrollTop(), "left": "30%", })
       $('.alert').show().delay(1000).fadeOut();
      }
  });



}





