
<?php

if(isset($_POST['start'])){
 shell_exec("sudo -u root /sbin/service issabel-ldap.service start");
    die();  
}



if(isset($_POST['save'])){
    
    $statament = 'OPTIONS="-ldappass '. $_POST['password'].'"';
    $path = '/etc/sysconfig/issabel-ldap';
    
    file_put_contents($path, $statament);
    shell_exec("sudo -u root /sbin/service issabel-ldap.service restart");

    echo json_encode(true);
    die();  
}


?>

